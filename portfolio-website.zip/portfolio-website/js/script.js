// Mobile nav toggle
const toggle = document.querySelector('.nav-toggle');
const navLinks = document.querySelector('.nav-links');

toggle.addEventListener('click', () => {
  const isOpen = navLinks.classList.toggle('is-open');
  navLinks.style.display = isOpen ? 'flex' : 'none';
});

// Close mobile nav after clicking a link
document.querySelectorAll('.nav-links a').forEach((link) => {
  link.addEventListener('click', () => {
    if (window.innerWidth <= 860) {
      navLinks.classList.remove('is-open');
      navLinks.style.display = 'none';
    }
  });
});
