# Personal Portfolio Website

A responsive, single-page portfolio built from scratch — no templates,
no page builders — using HTML5, CSS3, and Bootstrap-style responsive
layout principles.

## Stack
- HTML5 (semantic structure)
- CSS3 (custom design system, CSS Grid & Flexbox)
- Vanilla JavaScript (mobile navigation)

## Design concept
The visual language borrows from electrical schematics and datasheets —
a deliberate nod to an Electrical & Electronics Engineering background —
using a blueprint grid, "pin" labeled navigation, and a component-list
layout for the skills section.

## Project structure
```
portfolio-website/
├── index.html
├── css/
│   └── style.css
└── js/
    └── script.js
```

## Running locally
No build step required — it's static HTML/CSS/JS.

```bash
# from the project folder
python -m http.server 8000
```
Then visit `http://localhost:8000`.

Or just open `index.html` directly in a browser.

## Sections
- **Hero** — name, role, and current availability
- **About** — background and story
- **Skills** — categorized component list (Frontend, Programming, Database, Tooling)
- **Projects** — this site + the Dynamic Form Application
- **Experience** — Lucas TVS internship
- **Contact** — email, phone, location

## Customizing
Update the content directly in `index.html`. Colors and type scale are
defined as CSS custom properties at the top of `css/style.css` under
`:root` — change them there to re-theme the whole site.
